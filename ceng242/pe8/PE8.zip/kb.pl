% CHANGES DONE TO THIS FILE WILL BE OVERWRITTEN. 
% IT WILL HAVE NO EFFECT ON YOUR GRADE.

:- module(kb, [movie/6]).
%movie(Name, Director, Year, OscarNoms, EmmyNoms, GoldenGlobeNoms).

movie(moonlight, barry_jenkins, 2016, 8, 0, 6).
movie(inside, bo_burnham, 2021, 0, 6, 0).
movie(parasite, bong_joon_ho, 2019, 6, 0, 3).
movie(gone_girl, david_fincher, 2014, 1, 0, 4).
movie(fight_club, david_fincher, 1999, 1, 0, 0).
movie(social_network, david_fincher, 2010, 7, 0, 6).
movie(lady_bird, greta_gerwig, 2017, 5, 0, 4).
movie(little_women, greta_gerwig, 2019, 6, 0, 2).
movie(dead_poets_society, peter_weir, 1989, 4, 0, 4).
movie(coda, sian_heder, 2021, 3, 0, 2).
movie(what_we_do_in_the_shadows, taika_waititi, 2014, 0, 0, 0).
movie(jojo_rabbit, taika_waititi, 2019, 4, 0, 2).
movie(matrix, wachowski_sisters, 1999, 4, 0, 0).
movie(matrix_reloaded, wachowski_sisters, 2003, 0, 0, 0).
movie(matrix_revolutions, wachowski_sisters, 2003, 0, 0, 0).
movie(matrix_resurrections, wachowski_sisters, 2021, 0, 0, 0).
movie(fantastic_mr_fox, wes_anderson, 2009, 2, 0, 1).
movie(moonrise_kingdom, wes_anderson, 2012, 1, 0, 1).
movie(grand_budapest_hotel, wes_anderson, 2014, 9, 0, 4).
movie(isle_of_dogs, wes_anderson, 2018, 2, 0, 2).
movie(french_dispatch, wes_anderson, 2021, 0, 0, 1).