module PE3 where

import Data.List (find)

data Private = Private { idNumber :: Int, height :: Int, timeToSwap :: Int } deriving Show

data Cell = Empty | Full Private deriving Show

type Area = [[Cell]] 

--

-- Q1: A simple recursive algorithm does the trick
bubbleHumans :: [Int] -> [Int]
bubbleHumans (x1:x2:xs) = if x1 < x2 -- match (x1:x2:xs) first
                             then x2 : x1 : bubbleHumans xs -- switch, and skip x1 so that it is not swapped again
                             else x1 : bubbleHumans (x2 : xs) -- keep the same order and allow x2 to be swapped too
bubbleHumans singleOrEmpty = singleOrEmpty -- both single element and empty lists fall through to here

-- Q2: Same, but with some extra bells and whistles on the private data type,
-- using a key function and optionally in descending order.
--
-- We keep the same algorithm from before, with slight modifications.
bubblePrivates :: (Private -> Int) -> Bool -> [Private] -> [Private]
bubblePrivates keyFunc descOrder privates = go privates
  where go (x1:x2:xs) = if keyFunc x1 `lt` keyFunc x2 -- same as before, use lt defined below as infix with key function
                           then x2 : x1 : go xs
                           else x1 : go (x2 : xs)
        go singleOrEmpty = singleOrEmpty
        lt = if descOrder then (<) else (>) -- use the boolean to select the comparator function. neat!


-- Q3: Sort by applying bubble multiple times. Extra helper to calculate bubbling time.
--
-- iterate just applies bubbling repeatedly, and we get the result after applying it 2*n times.
-- See the explanation below for 2*n. 
-- bubbleWithTime is just an extended version of bubble that also adds the time, keeping progress
-- in a tuble. It's defined below.
sortPrivatesByHeight :: [Private] -> ([Private], Int)
sortPrivatesByHeight privates = iterate bubbleWithTime (privates, 0) !! (2 * length privates)
  where bubbleWithTime (p, t) = (bubblePrivates height True p, t + bubbleTime p)
-- ^ n bubble steps is not enough since values may be blocked by values on the left swapping,
-- but 2*n bubble steps will sort for sure, since a value should be able to move every 2 steps
-- for certain. 

-- Calculate how long one step of bubbling would take. 
bubbleTime :: [Private] -> Int
bubbleTime (p1:p2:ps) = if height p1 < height p2 -- can use the height selector directly
                           then max (max (timeToSwap p1) (timeToSwap p2)) $ bubbleTime ps -- max of both times & rest of the result
                           else bubbleTime (p2 : ps) -- no swap necessary, use the result from the rest
bubbleTime _ = 0 -- zero swap time for single elem & empty lists

-- Q4: Same sorting, but with a 2D [[Cell]] list as an extra layer.
ceremonialFormation :: Area -> (Area, Int)
ceremonialFormation grid = 
    let sortResults = map sortCellsByHeight grid -- apply sorting each file
        (sortedGrid, sortTimes) = unzip sortResults -- [(file, time)] -> (files, times)
     in (sortedGrid, maximum sortTimes) -- maximum of sortTimes is the total time, since files get sorted concurrently
        -- v As our sorting strategy, we use a nice transformation: convert empty cells to 
        --   a private with zero swapping time and zero id (impossible), and then convert
        --   them back after sorting. You've probably used it yourself :)
  where sortCellsByHeight cells = let (pris, t) = sortPrivatesByHeight $ map cell2pri cells
                                   in (map pri2cell pris, t)
        cell2pri Empty = Private 0 0 1 -- 0 id does not exist, and zero swap time works nicely
        cell2pri (Full private) = private
        pri2cell private@(Private idn _ _) = if idn == 0 then Empty else Full private -- decide depending on id


-- Q5: Swapping two privates in an area by ID. Somewhat difficult in Haskell!
--
-- I chose to flatten & remake the grid, which makes things easier, although
-- reshaping back into a grid is extra work.
swapPrivates :: Int -> Int -> Area -> Area
swapPrivates id1 id2 grid = 
    let cells = concat grid -- flatten into cells
     in case find (cellIdEquals id1) cells of -- find cell having private with id1, if it exists
          Nothing -> grid -- not found, do not change grid
          (Just c1) -> case find (cellIdEquals id2) cells of -- found, now search for id2
                         Nothing -> grid -- not found, do not change grid
                         (Just c2) -> let bothSwapped = swapBoth id1 id2 c1 c2 cells -- helper function for swapping the 2 privates in the list
                                          cellsPerFile = length $ head grid -- number of columns (cells in each file) in the grid
                                       in regrid cellsPerFile bothSwapped -- reshape the grid into the list

-- Simple recursive function for re-making a 2D list of 1D, given the number of cols (nested list
-- element count)
regrid :: Int -> [Cell] -> [[Cell]]
regrid _ [] = []
regrid n cs = take n cs : regrid n (drop n cs)

-- Helper function for checking the ID of a cell
cellIdEquals :: Int -> Cell -> Bool
cellIdEquals _ Empty = False
cellIdEquals targetId (Full private) = targetId == idNumber private

-- For swapping, we use a function that swaps both cells in one pass.
-- Why? Because two passes is problematic: Let's say we substitute (change)
-- c1 with c2 first. Then, the resulting list will now contain two c2 cells!
-- Which one will we swap with c1? Hard to manage, so just swap both in one pass!
swapBoth :: Int -> Int -> Cell -> Cell -> [Cell] -> [Cell]
swapBoth id1 id2 c1 c2 cells = map replaceBoth cells
  where replaceBoth c | cellIdEquals id1 c = c2
                      | cellIdEquals id2 c = c1
                      | otherwise = c

