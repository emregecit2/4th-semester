module PE4 where

import Data.List
import Data.Maybe

data Room = SeedStorage Int
          | Nursery Int Int
          | QueensChambers
          | Tunnel
          | Empty
          deriving Show

data Nestree = Nestree Room [Nestree] deriving Show

---------

-- Q1: Nutrition value of nest
-- A one-liner! Get the value of the current room,
-- recursively map over all subtrees and sum 'em up.
nestNutritionValue :: Nestree -> Int
nestNutritionValue (Nestree room subtrees) = 
    nutval room + sum (map nestNutritionValue subtrees)

-- A nice helper to get the nutrition value of a room.
nutval :: Room -> Int
nutval (SeedStorage n) = 3 * n
nutval (Nursery eggs larvae) = 7 * eggs + 10 * larvae
nutval _ = 0 -- all other room types fall through to 0 here

-- Q2: Nutrition value of each path
-- Easier than it seems with Haskell!
pathNutritionValues :: Nestree -> [Int]
pathNutritionValues (Nestree room []) = [nutval room] -- leaf case, only value of cur. in list
pathNutritionValues (Nestree room subtrees) = 
    map (nutval room +) $ concatMap pathNutritionValues subtrees
-- Again a one-liner! How? 
-- * Get paths from each subtree recursively, could use map: [Nestree] -> [[Int]]
-- * Append all the paths together, could use concat: [[Int]] -> [Int]
-- * concat . map is just concatMap!
-- * Then, add the value of the current room to each path's value with a map.
-- Easy, right?

-- Q3: Shallowest tunnel
-- Getting interesting, not very different though...
shallowestTunnel :: Nestree -> Maybe Int
shallowestTunnel (Nestree Tunnel _) = Just 1 -- got a tunnel! start with depth 1, no need to check below since they will be deeper.
-- shallowestTunnel (Nestree _ []) = Nothing -- Could add base case here, but this is actually covered by below code!
shallowestTunnel (Nestree _ subtrees) = -- Time for some recursion. 
    -- v mapMaybe applies the function only to (Just _) elements and gathers the results.
    let subdepths = mapMaybe shallowestTunnel subtrees -- shallowest tunnel from each subtree
     in if null subdepths -- empty list?
           then Nothing -- either subtrees == [] or no tunnels found below recursively
           else Just $ minimum subdepths + 1 -- add 1 to depth of shallowest tunnel found

-- Q4: Path to the queen's chambers
-- Very similar to Q3!
pathToQueen :: Nestree -> Maybe [Room]
pathToQueen (Nestree QueensChambers _) = Just [] -- path starts empty from the Queen
pathToQueen (Nestree room subtrees) =
    let subpaths = mapMaybe pathToQueen subtrees -- pathToQueen from each subtree
     in case subpaths of [] -> Nothing -- no Queen here or below, return Nothing
                         [path] -> Just $ room : path -- one path to Queen, prepend current room
                         _ -> error "There should be only one path to the queen" -- invalid input

-- Q5: Depth of the queen's chambers via shortcut
-- We'll just use our previous functions here and get it done easily!
quickQueenDepth :: Nestree -> Maybe Int
quickQueenDepth nest = 
    case pathToQueen nest of -- Is there a Queen?
      Nothing -> Nothing -- Nope, return Nothing
      (Just ptq) -> -- Found a path
        let baseQueenDepth = length ptq + 1 -- Depth without tunnels is length of path + 1
         in case shallowestTunnel nest of -- What about the shallowest tunnel?
          Nothing -> Just baseQueenDepth -- No tunnels anywhere, return depth with no tunnels
          (Just entryTunnelDepth) -> -- Found the shallowest, use that as entrance
            case findIndex isTunnel $ reverse ptq of 
              -- ^ This is the more confusing part. We have to find the -last- tunnel on
              --   the path to the Queen to find the shortest path and use that as the exit
              --   tunnel. Reverse the path list and apply findIndex from Data.List.
              Nothing -> Just baseQueenDepth -- No tunnel on path to queen
              (Just exitTunnelRemainder) -> 
                  -- ^ the index is the (number of edges - 1) remaining from the exit tunnel
                  Just $ min baseQueenDepth $ entryTunnelDepth + exitTunnelRemainder + 1
                  -- ^ the final calculation is just comparing the basic length to the
                  --   tunneled length of the path. Use the minimum.

-- a tiny helper to determine if a room is a tunnel
isTunnel :: Room -> Bool
isTunnel Tunnel = True
isTunnel _ = False

-- Fancy solution for Q5 using advanced concepts, as a teaser :)
-- "Advanced Concepts" is actually just the Monad instance of Maybe here, but still!
-- Observe how it makes the code much cleaner, with no nested case-ofs.
-- Haskell can be very enjoyable after going deeper...
qqdFancy :: Nestree -> Maybe Int
qqdFancy nest = do
    ptq <- pathToQueen nest -- returns Nothing if Nothing, thx to Maybe's Monad instance
    let baseQueenDepth = length ptq + 1
    return $ maybe baseQueenDepth id $ do -- return baseDepth if Nothing is returned from below
        entryTunnelDepth <- shallowestTunnel nest
        exitTunnelRemainder <- findIndex isTunnel $ reverse ptq
        return $ min baseQueenDepth $ entryTunnelDepth + exitTunnelRemainder + 1
        -- ^ return simply wraps the value with Just for the Maybe type,
        --   is also part of the Monad typeclass definition. I prefer using
        --   'pure' from Applicative instead, usually.
-- If this is interesting to you, feel free to come see me at any time with questions :) -DS


-- Example trees

exampleNest :: Nestree
exampleNest = 
  Nestree Tunnel [
    Nestree (SeedStorage 15) [
      Nestree (SeedStorage 81) []
    ],
    Nestree (Nursery 8 16) [
      Nestree Tunnel [
        Nestree QueensChambers [
          Nestree (Nursery 25 2) []
        ]
      ]
    ],
    Nestree Tunnel [
      Nestree Empty [],
      Nestree (SeedStorage 6) [
        Nestree Empty [],
        Nestree Empty []
      ]
    ]
  ]

-- Same example tree, with tunnels replaced by Empty
exampleNestNoTunnel :: Nestree
exampleNestNoTunnel = 
  Nestree Empty [
    Nestree (SeedStorage 15) [
      Nestree (SeedStorage 81) []
    ],
    Nestree (Nursery 8 16) [
      Nestree Empty [
        Nestree QueensChambers [
          Nestree (Nursery 25 2) []
        ]
      ]
    ],
    Nestree Empty [
      Nestree Empty [],
      Nestree (SeedStorage 6) [
        Nestree Empty [],
        Nestree Empty []
      ]
    ]
  ]
