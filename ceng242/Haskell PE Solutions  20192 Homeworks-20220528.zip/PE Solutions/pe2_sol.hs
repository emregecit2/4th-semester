module PE2 where

import Text.Printf

type Point = (Int, Int)
type Dimensions = (Int, Int)
type Vector = (Int, Int)

getRounded :: Double -> Double
getRounded x = read s :: Double
               where s = printf "%.2f" x

castIntToDouble x = (fromIntegral x) :: Double

-------------------------------------------------------------------------------------------------------------------------------
getVector :: String -> Vector
getVector d = case d of "Stay" -> (0,0)
                        "North" -> (0,1)
                        "NorthEast" -> (1,1)
                        "East" -> (1,0)
                        "SouthEast" -> (1,-1)
                        "South" -> (0,-1)
                        "SouthWest" -> (-1,-1)
                        "West" -> (-1,0)
                        "NorthWest" -> (-1,1)

-------------------------------------------------------------------------------------------------------------------------------
getAllVectors :: [String] -> [Vector]
getAllVectors l = [getVector d | d <- l]

-------------------------------------------------------------------------------------------------------------------------------
pathHelper :: Point -> [Vector] -> [Point] -> [Point]
pathHelper (cx,cy) [] acc = acc ++ [(cx, cy)]
pathHelper (cx,cy) ((dx,dy):ds) acc = pathHelper (cx + dx, cy + dy) ds (acc ++ [(cx, cy)])

producePath :: Point -> [String] -> [Point]
producePath initial actions = pathHelper initial (getAllVectors actions) []

-------------------------------------------------------------------------------------------------------------------------------
takePathInArea :: [Point] -> Dimensions -> [Point]
takePathInArea path (bx, by) = takeWhile (\(x,y) -> (x >= 0 && x < bx) && (y >= 0 && y < by)) path -- takeWhile get the elements upto given condition is no longer satisfied.

-------------------------------------------------------------------------------------------------------------------------------
isNotInPath o [] = True
isNotInPath o (p:ps) = if o == p then False else isNotInPath o ps

eliminate [] acc path = acc
eliminate (o:os) acc path = if isNotInPath o path then eliminate os (acc ++ [o]) path  else eliminate os acc path -- keep the objects whose locations are not visited, eliminate otherwise.

remainingObjects :: [Point] -> Dimensions -> [Point] -> [Point]
remainingObjects path border objects = eliminate objects [] $ takePathInArea path border

-------------------------------------------------------------------------------------------------------------------------------
successfulPaths :: [[Point]] -> Dimensions -> [Point] -> [[Point]]
successfulPaths paths border objects = [p | p <- paths, (takePathInArea p border) == p && (remainingObjects p border objects) == []]    -- filtering by list comprehension, if the path is equal to the path in area and no remaining objects then episode is successful.

averageStepsInSuccess :: [[Point]] -> Dimensions -> [Point] -> Double
averageStepsInSuccess paths border objects = getRounded $ (castIntToDouble total) / (castIntToDouble len)
                                            where successfuls = successfulPaths paths border objects
                                                  total = sum [length p | p <- successfuls]
                                                  len = length successfuls
